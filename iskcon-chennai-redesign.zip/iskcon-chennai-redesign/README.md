# ISKCON Chennai — Redesign

This is a Next.js + Tailwind CSS starter scaffold for the ISKCON Chennai redesign.

## Setup

1. Install dependencies: `npm install`
2. Run dev: `npm run dev`

Set environment variables for Stripe and BASE URL in a `.env.local` file.