import axios from 'axios'

export default function Contact(){
  async function handleSubmit(e){
    e.preventDefault()
    const data = {
      name: e.target.name.value,
      email: e.target.email.value,
      message: e.target.message.value
    }
    await axios.post('/api/contact', data)
    alert('Message sent — thank you!')
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h2 className="text-2xl font-semibold">Contact Us</h2>
      <form onSubmit={handleSubmit} className="mt-4 grid gap-3">
        <input name="name" placeholder="Your name" required className="p-2 border rounded" />
        <input name="email" type="email" placeholder="Your email" required className="p-2 border rounded" />
        <textarea name="message" placeholder="Message" rows={6} className="p-2 border rounded" />
        <button className="px-4 py-2 bg-primary text-white rounded">Send</button>
      </form>
    </div>
  )
}
