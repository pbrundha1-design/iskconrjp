import dynamic from 'next/dynamic'
const DonateForm = dynamic(() => import('../components/DonateForm'), { ssr: false })

export default function Donate(){
  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <h2 className="text-2xl font-semibold">Support the Temple</h2>
      <p className="mt-2 text-slate-600">Your donation helps running community programs and feeding prasadam.</p>
      <div className="mt-6"><DonateForm /></div>
    </div>
  )
}
