export default async function handler(req, res){
  if(req.method === 'POST'){
    const { name, email, message } = req.body
    console.log('Contact form received', name, email)
    // TODO: integrate with SendGrid or store in DB
    return res.status(200).json({ ok: true })
  }
  return res.status(405).end()
}
