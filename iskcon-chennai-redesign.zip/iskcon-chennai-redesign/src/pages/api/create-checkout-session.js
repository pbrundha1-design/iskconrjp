import Stripe from 'stripe'
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)

export default async function handler(req, res){
  if(req.method === 'POST'){
    const { amount } = req.body
    try{
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        mode: 'payment',
        line_items: [
          {
            price_data: {
              currency: 'inr',
              product_data: { name: 'Temple Donation' },
              unit_amount: amount
            },
            quantity: 1
          }
        ],
        success_url: `${process.env.NEXT_PUBLIC_BASE_URL}/donate?success=1`,
        cancel_url: `${process.env.NEXT_PUBLIC_BASE_URL}/donate?canceled=1`
      })
      return res.status(200).json({ sessionId: session.id })
    } catch(err){
      console.error(err)
      return res.status(500).json({ error: 'Stripe error' })
    }
  }
  return res.status(405).end()
}
