export default function About(){
  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <h2 className="text-2xl font-semibold">About ISKCON Chennai</h2>
      <p className="mt-4 text-slate-600">A short description... add history, mission, architecture and visiting info here.</p>
    </div>
  )
}
