import EventCard from '../components/EventCard'

export default function Events(){
  const events = [
    { id: '1', title: 'Festival of Radhastami', date: '2025-12-01', time: '06:00 PM', excerpt: 'Special celebrations.' }
  ]
  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <h2 className="text-2xl font-semibold">Events</h2>
      <div className="grid md:grid-cols-2 gap-4 mt-4">
        {events.map(e => <EventCard key={e.id} event={e} />)}
      </div>
    </div>
  )
}
