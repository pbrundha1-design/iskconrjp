import Hero from '../components/Hero'
import EventCard from '../components/EventCard'

const sampleEvents = [
  { id: '1', title: 'Morning Aarti & Kirtan', date: '2025-11-15', time: '07:30 AM', excerpt: 'Daily morning aarti with kirtan and prasadam.' },
  { id: '2', title: 'Sunday Bhagavatam Class', date: '2025-11-16', time: '10:00 AM', excerpt: 'Weekly class for devotees and visitors.' }
]

export default function Home(){
  return (
    <div>
      <Hero />
      <section className="max-w-6xl mx-auto px-4 py-12">
        <h2 className="text-2xl font-semibold">Upcoming Events</h2>
        <div className="grid md:grid-cols-2 gap-4 mt-4">
          {sampleEvents.map(e => <EventCard key={e.id} event={e} />)}
        </div>
      </section>
    </div>
  )
}
