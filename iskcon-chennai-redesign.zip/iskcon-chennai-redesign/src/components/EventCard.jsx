import Link from 'next/link'

export default function EventCard({event}){
  return (
    <article className="border rounded p-4">
      <h3 className="font-semibold">{event.title}</h3>
      <p className="text-sm text-slate-600">{event.date} • {event.time}</p>
      <p className="mt-2 text-sm">{event.excerpt}</p>
      <div className="mt-3">
        <Link href={`/events/${event.id}`} className="text-primary text-sm">Read more</Link>
      </div>
    </article>
  )
}
