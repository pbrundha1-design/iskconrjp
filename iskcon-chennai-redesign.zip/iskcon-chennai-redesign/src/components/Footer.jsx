import Link from 'next/link'

export default function Footer(){
  return (
    <footer className="bg-slate-900 text-white mt-12">
      <div className="max-w-6xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <h3 className="font-semibold">ISKCON Chennai</h3>
          <p className="text-sm text-slate-300">Sri Sri Radha Krishna Temple, ECR, Chennai</p>
        </div>
        <div>
          <h4 className="font-semibold">Quick Links</h4>
          <ul className="text-sm text-slate-300 mt-2">
            <li><Link href="/events">Events</Link></li>
            <li><Link href="/donate">Donate</Link></li>
            <li><Link href="/contact">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold">Contact</h4>
          <p className="text-sm text-slate-300 mt-2">Email: info@iskconchennai.org</p>
          <p className="text-sm text-slate-300">Phone: +91 81229 32650</p>
        </div>
      </div>
      <div className="border-t border-slate-700 py-4 text-center text-sm">© {new Date().getFullYear()} ISKCON Chennai</div>
    </footer>
  )
}
