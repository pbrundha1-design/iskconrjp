import Link from 'next/link'
import Image from 'next/image'
import { Menu } from 'lucide-react'

export default function Header(){
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Image src="/images/logo.png" alt="ISKCON Chennai" width={56} height={56} />
          <div>
            <h1 className="text-lg font-semibold">ISKCON Chennai</h1>
            <p className="text-sm text-slate-500">Sri Sri Radha Krishna Mandir, ECR</p>
          </div>
        </div>
        <nav className="hidden md:flex gap-6 items-center">
          <Link href="/">Home</Link>
          <Link href="/about">About</Link>
          <Link href="/events">Events</Link>
          <Link href="/donate">Donate</Link>
          <Link href="/contact">Contact</Link>
        </nav>
        <button className="md:hidden p-2"><Menu /></button>
      </div>
    </header>
  )
}
