import Image from 'next/image'

export default function Hero(){
  return (
    <section className="bg-gradient-to-b from-white to-slate-50">
      <div className="max-w-6xl mx-auto px-4 py-12 flex flex-col md:flex-row items-center gap-8">
        <div className="flex-1">
          <h2 className="text-3xl md:text-4xl font-extrabold">Welcome to ISKCON Chennai</h2>
          <p className="mt-4 text-slate-600">Experience devotional music, prasad and the divine presence of Sri Sri Radha Krishna. Join our daily aartis and community programs.</p>
          <div className="mt-6 flex gap-3">
            <a href="/events" className="px-4 py-2 rounded bg-primary text-white">View Events</a>
            <a href="/donate" className="px-4 py-2 rounded border">Donate</a>
          </div>
        </div>
        <div className="w-full md:w-1/2">
          <Image src="/images/temple-hero.jpg" width={700} height={420} alt="ISKCON Temple" className="rounded-lg shadow"/>
        </div>
      </div>
    </section>
  )
}
