'use client'
import { loadStripe } from '@stripe/stripe-js'
import axios from 'axios'

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY)

export default function DonateForm(){
  async function handleDonate(e){
    e.preventDefault()
    const amount = Number(e.target.amount.value) * 100 // paise
    const stripe = await stripePromise
    const res = await axios.post('/api/create-checkout-session', { amount })
    const { sessionId } = res.data
    await stripe.redirectToCheckout({ sessionId })
  }

  return (
    <form onSubmit={handleDonate} className="max-w-md">
      <label className="block">
        <span>Amount (INR)</span>
        <input name="amount" type="number" defaultValue={500} min={10} className="mt-1 block w-full p-2 border rounded" />
      </label>
      <button type="submit" className="mt-4 px-4 py-2 bg-primary text-white rounded">Donate via Stripe</button>
    </form>
  )
}
